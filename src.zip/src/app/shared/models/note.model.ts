export class Note {

  public title : string;
  public content : string;
  public date_add : string;
  public date_expire : string;
  public id : number;

  constructor (title : string, content : string, date_add : string, date_expire : string, id? : number)
  {
    this.title = title;
    this.content = content;
    this.date_add = date_add;
    this.date_expire = date_expire;
    this.id = id;
  }

}
