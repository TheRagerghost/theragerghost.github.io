import { Pipe, PipeTransform } from '@angular/core';
import { Note } from "../models/note.model";
import { NotesService } from "../services/notes.service";
import { isNullOrUndefined } from "util";

@Pipe({
  name: 'utility'
})
export class UtilityPipe implements PipeTransform {

  constructor (private notesService : NotesService)
  {

  }

  transform(notes: Note[], type: string): any {
    if(!isNullOrUndefined(notes))
    {
      switch (type)
      {
        case "id_fromtop":
            notes.sort((a, b) => {return a.id-b.id;});
          break;

        case "id_frombot":
            notes.sort((a, b) => {return b.id-a.id;});
          break;

        case "exp_fromtop":
            notes.sort((a, b) => this.notesService.compareDates(a.date_expire, b.date_expire));
          break;

        case "exp_frombot":
            notes.sort((a, b) => this.notesService.compareDates(b.date_expire, a.date_expire));
          break;
      }
    }
    return notes;
  }

}
