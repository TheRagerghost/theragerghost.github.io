import { UtilityPipe } from './utility.pipe';

describe('UtilityPipe', () => {
  it('create an instance', () => {
    const pipe = new UtilityPipe();
    expect(pipe).toBeTruthy();
  });
});
