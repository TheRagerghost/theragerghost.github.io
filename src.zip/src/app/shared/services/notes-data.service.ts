import { Injectable } from '@angular/core';
import { DatabaseService } from "./database.service";
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})

export class NotesDataService extends DatabaseService {

  header: HttpHeaders;
  url = "notes";

  constructor(httpClient: HttpClient) {
    super (httpClient);
    this.header = new HttpHeaders();
    this.header.set ('Content-type', 'application/json');
  }

  async getData () {
    return await this.get (this.url, this.header).toPromise();
  }

  postData (data) {
    return this.post (this.url, data, this.header).toPromise();
  }

  putData (id: number, data) {
    return this.put (`${this.url}/${id}`, data, this.header).toPromise();
  }

  deleteData (id: number) {
    return this.delete (`${this.url}/${id}`, this.header).toPromise();
  }

}
