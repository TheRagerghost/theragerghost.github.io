import { Injectable, OnInit } from '@angular/core';
import { isNullOrUndefined } from "util";
import { Note } from "../models/note.model";
import { NotesDataService } from "../services/notes-data.service"

@Injectable({
  providedIn: 'root'
})
export class NotesService {

  public notes : any;

  constructor(private notesData : NotesDataService) {
    this.loadNotes();
    //this.addNote(new Note("Second", "Prepare uranus!", "15.12.2019", "15.01.2019"));
  }

  ngOnInit() {

  }

  async loadNotes () {
    try {
      let data = this.notesData.getData();
      this.notes = (isNullOrUndefined(await data)) ? [] : await data;
    } catch (err) {
      console.log(err);
    }

    console.log(this.notes);
  }

  getNoteByID (id: number) {
    let note : Note;
    this.notes.forEach(p => {if(p.id == id) note = new Note(p.title, p.content, p.date_add, p.date_expire, p.id);});
    return note;
  }

  async addNote (note : Note) {

    note.id = (this.notes.length) ? this.notes[this.notes.length - 1].id + 1 : 1;
    this.notes.push(note);

    try {
      await this.notesData.postData({ title : note.title, content : note.content,
                                      date_add : note.date_add, date_expire : note.date_expire });
    }
    catch (e) {
      console.error(e);
    }


    console.log(this.notes);
  }

  async editNote (note : Note) {

    console.log(note);
    try {
      await this.notesData.putData(note.id, { title : note.title, content : note.content,
                                              date_add : note.date_add, date_expire : note.date_expire });
    }
    catch (e) {
      console.error(e);
    }
  }

  async deleteNote (noteID : number) {

    this.notes.splice(this.notes.indexOf(this.notes.find((element, index, array) => {
      return (element.id === noteID)
    })), 1);

    try {
      await this.notesData.deleteData(noteID);
    }
    catch (e) {
      console.error(e);
    }
  }

  convertDateToString (date : number) {
    let s = date.toString();

    let dd = s.slice(0,2);

    let mm = s.slice(2,4);

    let yyyy = s.slice(4);

    s = dd + "." + mm + "." + yyyy;

    if(isNaN(Date.parse(this.stringToDateFormat(s))))
    {
      let d = new Date();
      d.setDate(d.getDate() + 1);
      s = d.toLocaleDateString("ru-RU");
    }

    return s;
  }

  convertDateToNum (date : string) {

    let dd = date.slice(0,2);

    let mm = date.slice(3,5);

    let yyyy = date.slice(6);

    return parseInt(dd+mm+yyyy);
  }

  compareDates (a : string, b : string) {
    let dateA = Date.parse(this.stringToDateFormat(a));
    let dateB = Date.parse(this.stringToDateFormat(b));

    if(dateA > dateB)
      return 1;
    else if (dateB > dateA)
      return -1;
    else
      return 0;
  }

  stringToDateFormat(s : string)
  {
    return s.slice(6) + "-" + s.slice(3,5) + "-" + s.slice(0,2);
  }
}
