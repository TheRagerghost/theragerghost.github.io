import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {Note} from "../shared/models/note.model";
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {NotesService} from "../shared/services/notes.service";
import {ActivatedRoute, Router} from "@angular/router";
import {isNullOrUndefined} from "util";

@Component({
  selector: 'app-notes-add',
  templateUrl: './notes-add.component.html',
  styleUrls: ['./notes-add.component.css']
})
export class NotesAddComponent implements OnInit {

  id: number;
  addForm: FormGroup;
  disabled_form = false;
  edit_form = false;
  editNote : Note = null;

  constructor(private activatedRouter: ActivatedRoute, private router: Router, private notesServise: NotesService) {

    this.activatedRouter.params.subscribe(param => {
       this.id = param.id;
    });

    if (!isNullOrUndefined(this.id))console.log(this.id);
  }

  ngOnInit() {
    let note = this.notesServise.getNoteByID(this.id);
    if (isNullOrUndefined(note)) note = {title: "", content: "", date_add: new Date().toLocaleDateString('ru-RU'), date_expire: "", id: this.id};
    else this.edit_form = true;
    this.addForm = new FormGroup( {
      title: new FormControl({value: note.title, disabled: this.disabled_form}, [Validators.required]),
      content: new FormControl({value: note.content, disabled: this.disabled_form}, [Validators.required]),
      date_expire: new FormControl({value: this.notesServise.convertDateToNum(note.date_expire), disabled: this.disabled_form}, [Validators.required])
    })

    this.editNote = note;
  }

  async saveNote() {
    let result;
    if (this.id != null) {
      let note = new Note (this.addForm.value.title, this.addForm.value.content, this.editNote.date_add , this.notesServise.convertDateToString(this.addForm.value.date_expire), parseInt(this.id.toString(), 10));
      this.notesServise.notes[this.id] = note;
      result = this.notesServise.editNote(note);
      this.id = null;
      this.editNote = null;
    }
    else {
      let note = new Note (this.addForm.value.title, this.addForm.value.content, new Date().toLocaleDateString('ru-RU') , this.notesServise.convertDateToString(this.addForm.value.date_expire), this.id);
      result = this.notesServise.addNote(note);
    }

    this.router.navigate([``]);

  }

}
