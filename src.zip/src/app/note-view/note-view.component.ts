import { Component, Input, OnInit} from '@angular/core';
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { Note } from "../shared/models/note.model";
import { NotesService } from "../shared/services/notes.service"

@Component({
  selector: 'app-note-view',
  templateUrl: './note-view.component.html',
  styleUrls: ['./note-view.component.css']
})
export class NoteViewComponent implements OnInit {

  @Input() note: Note;
  expired = false;

  constructor(private notesService : NotesService) {

  }

  ngOnInit() {
    this.expired = this.notesService.compareDates(new Date().toLocaleDateString("ru-RU"), this.note.date_expire) == 1;
  }

  delete (id : number)
  {
    this.notesService.deleteNote(this.note.id);
  }

}
